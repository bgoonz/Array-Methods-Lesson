const hungryMonkeys = ["🐒", "🦍", "🦧"];
const feededMonkeys = hungryMonkeys.map(m => m + "🍌");
console.log(feededMonkeys);// ["🐒🍌", "🦍🍌", "🦧🍌"]